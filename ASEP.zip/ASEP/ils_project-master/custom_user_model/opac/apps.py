from django.apps import AppConfig


class OpacConfig(AppConfig):
    name = 'opac'
