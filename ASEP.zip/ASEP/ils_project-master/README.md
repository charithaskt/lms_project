# INTEGRATED LIBRARY MANAGEMENT SYSTEM__ILS

> This project is made using python and django

intranet app has all basic models<br>
intranet app is the one where we have customized the django admin interface<br>
accounts has user modules and mail authentication part<br>
# Do the following installations in your virtualenvironment
<br>pip3 install django_tables2
<br>  pip3 install djangorestframework
 <br>  pip3 install django-sql-explorer
 <br>pip3 install django-filter
 <br>  pip3 install django_bootstrap3
 <br>  pip3 install djangorestframework_jwt
 <br> pip3 install django-tablib<br>
 pip3 install python_magic
 
