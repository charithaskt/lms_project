from django.urls import path
from .import views

app_name='booklist'

urlpatterns = [

    path('post/create/', views.post_create, name='post_create'),
    path('post/<int:id>',views.post_detail,name='post_detail'),
    path('comment/<int:id>/delete/', views.comment_delete, name='comment_delete'),
]
