from django.contrib import admin
from .models import TeacherPost,Profile,Images,Comment

admin.site.register(TeacherPost)
admin.site.register(Profile)
admin.site.register(Images)
admin.site.register(Comment)
