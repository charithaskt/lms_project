from django.apps import AppConfig


class booklistConfig(AppConfig):
    name = 'booklist'
