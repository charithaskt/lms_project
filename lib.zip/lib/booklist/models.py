from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse


class TeacherPost(models.Model):

    author = models.CharField(max_length=100,default='J.K Rowling')
    title = models.CharField(max_length=100)
    tags = models.CharField(max_length=50,blank=True)
    created_time = models.DateTimeField(auto_now_add=True)
    def get_tags(self):
        arr = []
        arr = self.tags.split(' ')
        return arr

    def __str__(self):
        return str(self.title)




class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)

    def __str__(self):
        return "Profile {}".format(self.user.username)


class Images(models.Model):
    post = models.ForeignKey(TeacherPost, on_delete=models.CASCADE)
    image = models.ImageField(upload_to='images/', blank=True, null=True)

    def __str__(self):
        return self.post.title + ' image'

class Comment(models.Model):
    post = models.ForeignKey(TeacherPost, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField(max_length=500)

    def __str__(self):
        return '{}'.format(self.post.title)+"Comment"