from django.shortcuts import render, get_object_or_404, redirect
from .models import Profile,Images
from .forms import *
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse , Http404
from django.forms import modelformset_factory


def user_login(request):
    if request.method == 'POST':
        form = ProfessorLogin(request.POST)
        if form.is_valid():
            username = request.POST['username']
            password = request.POST['password']

            user = authenticate(username=username, password=password)

            if user:
                if user.is_active:
                    login(request, user)
                    return HttpResponse('you are now logged in')

                else:
                    return HttpResponse('User is not active')

            else:
                return HttpResponse('User is not available')

    else:
        form = ProfessorLogin()
        contexts={'form':form}

    return render(request,'booklist/login.html', contexts)


def user_logout(request):
    logout(request)
    return redirect('index')


def post_create(request):
    ImageFormset = modelformset_factory(Images, fields=('image',))

    if request.method == 'POST':
        form = PostCreateForm(request.POST)
        formset = ImageFormset(request.POST or None, request.FILES or None)
        if form.is_valid():
            post = form.save(commit=False)
            #post.author = request.user
            post.save()
            print(formset)
            for file in formset:
                if file.cleaned_data:
                    try:
                        photo = Images(post=post,image=file.cleaned_data.get('image'))
                        photo.save()
                    except Exception as e:
                        break
                else:
                    return HttpResponse("error")

            return redirect('post_list')
        else:
            return HttpResponse("jjj")

    else:
        form = PostCreateForm()
        formset = ImageFormset(queryset=Images.objects.none())
    contexts = {
        'form':form,
        'formset':formset,

    }
    return render(request, 'booklist/newbook.html', contexts)








def post_list(request):
    all_post=TeacherPost.objects.all()
    context={
        'all_post':all_post
    }
    return render(request,'booklist/booklist.html',context)


def post_detail(request,id):
    post = get_object_or_404(TeacherPost, id=id)
    comments = Comment.objects.filter(post=post)

    comment_form = CommentForm()
    if request.method == 'POST':
        comment_form = CommentForm(request.POST or None)
        if comment_form.is_valid():
            content = request.POST.get('content')
            comment = Comment.objects.create(post=post, user=request.user, content=content)
            comment.save()
            return redirect('post_list')

        else:
            comment_form = CommentForm()
    contexts = {
        'post': post,
        'comments': comments,
        'comment_form': comment_form,
    }

    return render(request, 'booklist/details.html', contexts)




def comment_delete(request, id):
    comment = get_object_or_404(Comment, id=id)
    comment.delete()
    return redirect('post_list')